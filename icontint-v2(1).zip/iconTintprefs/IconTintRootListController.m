#import <Preferences/PSListController.h>
#import <Preferences/PSSpecifier.h>
#import <UIKit/UIKit.h>
#import <QuartzCore/QuartzCore.h>

@interface CAFilter : NSObject
+ (instancetype)filterWithType:(NSString *)type;
@end

static CFStringRef const kDomain = CFSTR("com.vibe.icontint");

static double ReadDouble(CFStringRef key, double def) {
    double result = def;
    CFPropertyListRef v = CFPreferencesCopyAppValue(key, kDomain);
    if (v) {
        if (CFGetTypeID(v) == CFNumberGetTypeID()) {
            CFNumberGetValue((CFNumberRef)v, kCFNumberDoubleType, &result);
        }
        CFRelease(v);
    }
    return result;
}

static double Clamp01(double x) {
    return x < 0 ? 0 : (x > 1 ? 1 : x);
}

#pragma mark - Предпросмотр

// Ряд примерных иконок, к которому применяется тот же эффект, что и на домашнем экране
@interface IconTintPreviewView : UIView
@property (nonatomic, strong) NSArray<UIView *> *tiles;
- (void)refresh;
@end

@implementation IconTintPreviewView

- (instancetype)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
        self.autoresizingMask = UIViewAutoresizingFlexibleWidth;
        NSArray *symbols = @[@"phone.fill", @"message.fill", @"safari.fill", @"camera.fill", @"gearshape.fill"];
        NSArray *colors = @[[UIColor systemGreenColor], [UIColor systemBlueColor], [UIColor systemTealColor],
                            [UIColor systemRedColor], [UIColor systemPurpleColor]];
        NSMutableArray *tiles = [NSMutableArray array];
        for (NSUInteger i = 0; i < symbols.count; i++) {
            UIView *tile = [[UIView alloc] init];
            tile.backgroundColor = colors[i];
            tile.layer.cornerRadius = 13;

            UIImageView *glyph = [[UIImageView alloc] initWithImage:[UIImage systemImageNamed:symbols[i]]];
            glyph.tintColor = [UIColor whiteColor];
            glyph.contentMode = UIViewContentModeScaleAspectFit;
            glyph.tag = 1;
            [tile addSubview:glyph];

            [self addSubview:tile];
            [tiles addObject:tile];
        }
        self.tiles = tiles;
    }
    return self;
}

- (void)layoutSubviews {
    [super layoutSubviews];
    CGFloat size = 56.0;
    CGFloat count = (CGFloat)self.tiles.count;
    CGFloat gap = (self.bounds.size.width - size * count) / (count + 1.0);
    if (gap < 4.0) gap = 4.0;
    for (NSUInteger i = 0; i < self.tiles.count; i++) {
        UIView *tile = self.tiles[i];
        tile.frame = CGRectMake(gap + (CGFloat)i * (size + gap), (self.bounds.size.height - size) / 2.0, size, size);
        UIView *glyph = [tile viewWithTag:1];
        glyph.frame = CGRectInset(tile.bounds, 14.0, 14.0);
    }
}

- (void)refresh {
    NSInteger mode = (NSInteger)ReadDouble(CFSTR("mode"), 3);
    double hue = Clamp01(ReadDouble(CFSTR("hue"), 0.05));
    double sat = Clamp01(ReadDouble(CFSTR("sat"), 1.0));
    double strength = Clamp01(ReadDouble(CFSTR("strength"), 1.0));

    if (mode == 2) {
        mode = (self.traitCollection.userInterfaceStyle == UIUserInterfaceStyleDark) ? 1 : 0;
    }

    CAFilter *filter = nil;
    if (mode == 1) {
        filter = [CAFilter filterWithType:@"multiplyColor"];
        UIColor *c = [UIColor colorWithWhite:0.38 alpha:1.0];
        [filter setValue:(id)c.CGColor forKey:@"inputColor"];
    } else if (mode == 3) {
        filter = [CAFilter filterWithType:@"colorMonochrome"];
        UIColor *c = [UIColor colorWithHue:hue saturation:sat brightness:1.0 alpha:1.0];
        [filter setValue:(id)c.CGColor forKey:@"inputColor"];
        [filter setValue:@(strength) forKey:@"inputAmount"];
        [filter setValue:@(0.0) forKey:@"inputBias"];
    }

    [CATransaction begin];
    [CATransaction setDisableActions:YES];
    self.layer.filters = filter ? @[filter] : nil;
    [CATransaction commit];
}

- (void)traitCollectionDidChange:(UITraitCollection *)previousTraitCollection {
    [super traitCollectionDidChange:previousTraitCollection];
    [self refresh];
}

@end

#pragma mark - Контроллер настроек

@interface IconTintRootListController : PSListController
@property (nonatomic, strong) IconTintPreviewView *preview;
@end

@implementation IconTintRootListController

- (NSArray *)specifiers {
    if (!_specifiers) {
        _specifiers = [self loadSpecifiersFromPlistName:@"Root" target:self];
    }
    return _specifiers;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.preview = [[IconTintPreviewView alloc] initWithFrame:CGRectMake(0, 0, 320, 110)];
    id table = [self valueForKey:@"table"];
    if ([table isKindOfClass:[UITableView class]]) {
        ((UITableView *)table).tableHeaderView = self.preview;
    }
    [self.preview refresh];
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    [self.preview refresh];
}

- (void)setPreferenceValue:(id)value specifier:(PSSpecifier *)specifier {
    [super setPreferenceValue:value specifier:specifier];
    [self.preview refresh];
}

@end
