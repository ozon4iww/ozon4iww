#import <Preferences/PSListController.h>

@interface IconTintRootListController : PSListController
@end

@implementation IconTintRootListController

- (NSArray *)specifiers {
    if (!_specifiers) {
        _specifiers = [self loadSpecifiersFromPlistName:@"Root" target:self];
    }
    return _specifiers;
}

@end
