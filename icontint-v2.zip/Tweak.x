#import <UIKit/UIKit.h>
#import <QuartzCore/QuartzCore.h>
#import <objc/runtime.h>

// Приватный класс CoreAnimation для цветовых фильтров слоя
@interface CAFilter : NSObject
+ (instancetype)filterWithType:(NSString *)type;
@end

@interface SBIconImageView : UIView
@end

@interface SBFolderIconImageView : SBIconImageView
@end

static CFStringRef const kDomain = CFSTR("com.vibe.icontint");
static CFStringRef const kNotif = CFSTR("com.vibe.icontint/prefschanged");

typedef NS_ENUM(NSInteger, ITMode) {
    ITModeLight = 0,   // без эффекта
    ITModeDark = 1,    // затемнённые иконки
    ITModeAuto = 2,    // светлые/тёмные по теме системы
    ITModeTinted = 3   // одноцветные иконки
};

static NSInteger gMode = ITModeTinted;
static CGFloat gHue = 0.05;
static CGFloat gSat = 1.0;
static CGFloat gStrength = 1.0;
static NSInteger gVersion = 0;

static NSHashTable<UIView *> *gViews;
static Class gFolderClass;
static Class gGridClass;

static const void *kFilterKey = &kFilterKey;
static const void *kSigKey = &kSigKey;

#pragma mark - Настройки

static CGFloat Clamp01(CGFloat x) {
    return x < 0 ? 0 : (x > 1 ? 1 : x);
}

static NSNumber *ReadNumber(CFStringRef key) {
    CFPropertyListRef v = CFPreferencesCopyAppValue(key, kDomain);
    if (!v) return nil;
    NSNumber *n = nil;
    if (CFGetTypeID(v) == CFNumberGetTypeID() || CFGetTypeID(v) == CFBooleanGetTypeID()) {
        n = [(__bridge NSNumber *)v copy];
    }
    CFRelease(v);
    return n;
}

static void LoadPrefs(void) {
    CFPreferencesAppSynchronize(kDomain);

    NSNumber *n = ReadNumber(CFSTR("mode"));
    gMode = n ? n.integerValue : ITModeTinted;
    if (gMode < ITModeLight || gMode > ITModeTinted) gMode = ITModeTinted;

    n = ReadNumber(CFSTR("hue"));
    gHue = n ? Clamp01(n.doubleValue) : 0.05;

    n = ReadNumber(CFSTR("sat"));
    gSat = n ? Clamp01(n.doubleValue) : 1.0;

    n = ReadNumber(CFSTR("strength"));
    gStrength = n ? Clamp01(n.doubleValue) : 1.0;

    gVersion++;
}

#pragma mark - Фильтры

static NSInteger EffectiveMode(UIView *view) {
    if (gMode == ITModeAuto) {
        return view.traitCollection.userInterfaceStyle == UIUserInterfaceStyleDark ? ITModeDark : ITModeLight;
    }
    return gMode;
}

static CAFilter *MakeFilter(NSInteger mode) {
    if (mode == ITModeDark) {
        CAFilter *f = [CAFilter filterWithType:@"multiplyColor"];
        UIColor *c = [UIColor colorWithWhite:0.38 alpha:1.0];
        [f setValue:(id)c.CGColor forKey:@"inputColor"];
        return f;
    }
    if (mode == ITModeTinted) {
        UIColor *c = [UIColor colorWithHue:gHue saturation:gSat brightness:1.0 alpha:1.0];
        CAFilter *f = [CAFilter filterWithType:@"colorMonochrome"];
        [f setValue:(id)c.CGColor forKey:@"inputColor"];
        [f setValue:@(gStrength) forKey:@"inputAmount"];
        [f setValue:@(0.0) forKey:@"inputBias"];
        return f;
    }
    return nil;
}

// Ставит (или обновляет) наш фильтр, не трогая фильтры самой системы
static void ApplyToView(UIView *view) {
    if (!view || !gViews) return;
    [gViews addObject:view];

    CALayer *layer = view.layer;
    NSInteger mode = EffectiveMode(view);
    NSInteger sig = gVersion * 10 + mode;

    id old = objc_getAssociatedObject(view, kFilterKey);
    NSNumber *oldSig = objc_getAssociatedObject(view, kSigKey);
    BOOL present = old && [layer.filters containsObject:old];

    // Ничего не изменилось и фильтр на месте: выходим
    if (oldSig && oldSig.integerValue == sig && (present || mode == ITModeLight)) return;

    NSMutableArray *filters = [NSMutableArray array];
    for (id f in layer.filters) {
        if (f != old) [filters addObject:f];
    }
    CAFilter *nf = MakeFilter(mode);
    if (nf) [filters addObject:nf];

    [CATransaction begin];
    [CATransaction setDisableActions:YES];
    layer.filters = filters.count ? filters : nil;
    [CATransaction commit];

    objc_setAssociatedObject(view, kFilterKey, nf, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
    objc_setAssociatedObject(view, kSigKey, @(sig), OBJC_ASSOCIATION_RETAIN_NONATOMIC);
}

static void RemoveOurFilter(UIView *view) {
    id old = objc_getAssociatedObject(view, kFilterKey);
    if (!old) return;
    NSMutableArray *filters = [NSMutableArray array];
    for (id f in view.layer.filters) {
        if (f != old) [filters addObject:f];
    }
    [CATransaction begin];
    [CATransaction setDisableActions:YES];
    view.layer.filters = filters.count ? filters : nil;
    [CATransaction commit];
    objc_setAssociatedObject(view, kFilterKey, nil, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
    objc_setAssociatedObject(view, kSigKey, nil, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
}

#pragma mark - Папки (мини-иконки)

static BOOL IsGridImage(UIImage *img) {
    return gGridClass && img && [img isKindOfClass:gGridClass];
}

static void TintGridSubviews(UIView *root, int depth) {
    for (UIView *sub in root.subviews) {
        if ([sub isKindOfClass:[UIImageView class]] && IsGridImage(((UIImageView *)sub).image)) {
            ApplyToView(sub);
        }
        if (depth > 0) TintGridSubviews(sub, depth - 1);
    }
}

// Для обычных иконок красим сам вид, для папок только картинки с мини-иконками
// (чтобы не перекрашивать размытый фон папки)
static void ApplyTint(UIView *view) {
    if (gFolderClass && [view isKindOfClass:gFolderClass]) {
        TintGridSubviews(view, 5);
        return;
    }
    ApplyToView(view);
}

#pragma mark - Хуки

%hook SBIconImageView
- (void)layoutSubviews {
    %orig;
    ApplyTint(self);
}
- (void)didMoveToWindow {
    %orig;
    ApplyTint(self);
}
- (void)prepareForReuse {
    %orig;
    ApplyTint(self);
}
- (void)updateImageAnimated:(BOOL)animated {
    %orig;
    ApplyTint(self);
}
// Система сбрасывает layer.filters при нажатии на иконку и при выходе из приложения.
// Поэтому ставим фильтр обратно после этих вызовов.
- (void)setBrightness:(double)brightness {
    %orig;
    ApplyTint(self);
}
- (void)_updateOverlayAlpha {
    %orig;
    ApplyTint(self);
}
- (void)traitCollectionDidChange:(UITraitCollection *)previous {
    %orig;
    ApplyTint(self);
}
%end

%hook SBFolderIconImageView
- (void)layoutSubviews {
    %orig;
    TintGridSubviews(self, 5);
}
- (void)didMoveToWindow {
    %orig;
    TintGridSubviews(self, 5);
}
%end

// Картинки-сетки с мини-иконками (папки на экране и в Библиотеке приложений)
%hook UIImageView
- (void)setImage:(UIImage *)image {
    %orig;
    if (IsGridImage(image)) {
        ApplyToView(self);
    } else if (objc_getAssociatedObject(self, kFilterKey)) {
        RemoveOurFilter(self);
    }
}
%end

#pragma mark - Живое обновление настроек

static void PrefsChanged(CFNotificationCenterRef center, void *observer, CFStringRef name, const void *object, CFDictionaryRef userInfo) {
    dispatch_async(dispatch_get_main_queue(), ^{
        LoadPrefs();
        for (UIView *v in [gViews allObjects]) {
            ApplyToView(v);
        }
    });
}

%ctor {
    gViews = [NSHashTable weakObjectsHashTable];
    gFolderClass = NSClassFromString(@"SBFolderIconImageView");
    gGridClass = NSClassFromString(@"SBIconGridImage");
    LoadPrefs();
    CFNotificationCenterAddObserver(CFNotificationCenterGetDarwinNotifyCenter(), NULL, PrefsChanged, kNotif, NULL, CFNotificationSuspensionBehaviorCoalesce);
}
